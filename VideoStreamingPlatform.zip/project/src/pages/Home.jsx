import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import { useVideos } from '../contexts/VideoContext'
import VideoCarousel from '../components/videos/VideoCarousel'
import VideoGrid from '../components/videos/VideoGrid'
import Loading from '../components/common/Loading'

const Home = () => {
  const { featured, trending, loading, getContinueWatchingVideos } = useVideos()
  const [continueWatchingVideos, setContinueWatchingVideos] = useState([])

  useEffect(() => {
    if (!loading) {
      setContinueWatchingVideos(getContinueWatchingVideos())
    }
  }, [loading, getContinueWatchingVideos])

  if (loading) {
    return <Loading />
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Hero Carousel */}
      {featured.length > 0 && (
        <VideoCarousel videos={featured} />
      )}
      
      {/* Main Content */}
      <div className="container-custom py-8">
        {/* Continue Watching Section */}
        {continueWatchingVideos.length > 0 && (
          <section className="mb-12">
            <div className="flex justify-between items-center mb-4">
              <h2 className="heading-md">Continue Watching</h2>
              <Link to="/profile" className="text-accent-950 hover:text-accent-600 flex items-center gap-1 text-sm font-medium">
                View All <FiArrowRight />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 gap-4 md:gap-6">
              {continueWatchingVideos.slice(0, 4).map(video => (
                <VideoGrid
                  key={video.id}
                  videos={[video]}
                  continueWatching={true}
                />
              ))}
            </div>
          </section>
        )}
        
        {/* Trending Section */}
        <section className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <h2 className="heading-md">Trending Now</h2>
            <Link to="/browse" className="text-accent-950 hover:text-accent-600 flex items-center gap-1 text-sm font-medium">
              View All <FiArrowRight />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {trending.slice(0, 5).map(video => (
              <VideoGrid
                key={video.id}
                videos={[video]}
              />
            ))}
          </div>
        </section>
        
        {/* Category Showcase */}
        <section className="mb-12">
          <h2 className="heading-md mb-4">Popular Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {['Action', 'Comedy', 'Sci-Fi', 'Drama'].map((category, index) => (
              <Link key={index} to="/browse">
                <motion.div 
                  className="rounded-lg overflow-hidden relative h-40 group"
                  whileHover={{ scale: 1.03 }}
                >
                  <img 
                    src={`https://images.pexels.com/photos/${[2873486, 1105666, 924824, 1438072][index]}/pexels-photo-${[2873486, 1105666, 924824, 1438072][index]}.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1`} 
                    alt={category} 
                    className="w-full h-full object-cover transition-all duration-300 group-hover:brightness-75"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-300/90 to-transparent flex items-end">
                    <h3 className="text-white text-xl font-bold p-4">{category}</h3>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </motion.div>
  )
}

export default Home