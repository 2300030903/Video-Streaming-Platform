import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useVideos } from '../contexts/VideoContext'
import VideoGrid from '../components/videos/VideoGrid'
import CategoryList from '../components/videos/CategoryList'
import Loading from '../components/common/Loading'

const Browse = () => {
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [filteredVideos, setFilteredVideos] = useState([])
  const { videos, categories, getVideosByCategory, loading } = useVideos()

  // Update filtered videos when category changes
  useEffect(() => {
    if (!loading) {
      if (selectedCategory) {
        setFilteredVideos(getVideosByCategory(selectedCategory))
      } else {
        setFilteredVideos(videos)
      }
    }
  }, [selectedCategory, videos, getVideosByCategory, loading])

  const handleCategorySelect = (categoryId) => {
    setSelectedCategory(categoryId)
  }

  if (loading) {
    return <Loading />
  }

  return (
    <motion.div
      className="container-custom py-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h1 className="heading-lg mb-2">Browse</h1>
        <p className="text-gray-400">Discover movies and shows in our library</p>
      </div>
      
      <CategoryList 
        onCategorySelect={handleCategorySelect}
        selectedCategory={selectedCategory}
      />
      
      <VideoGrid
        videos={filteredVideos}
        title={selectedCategory 
          ? `${categories.find(c => c.id === selectedCategory)?.name} (${filteredVideos.length})`
          : `All Videos (${filteredVideos.length})`
        }
        emptyMessage="No videos found in this category"
      />
    </motion.div>
  )
}

export default Browse