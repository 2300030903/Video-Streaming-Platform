import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiUser, FiMail, FiLock, FiAlertCircle } from 'react-icons/fi'
import { useAuth } from '../contexts/AuthContext'
import Input from '../components/common/Input'
import Button from '../components/common/Button'

const Register = () => {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { register } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    
    if (password !== confirmPassword) {
      return setError('Passwords do not match')
    }
    
    try {
      setLoading(true)
      await register(name, email, password)
      navigate('/')
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <motion.div
      className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="w-full max-w-md bg-dark-200 p-8 rounded-lg shadow-lg">
        <div className="text-center mb-8">
          <h1 className="heading-lg mb-2">Create Account</h1>
          <p className="text-gray-400">Join StreamVista today</p>
        </div>
        
        {error && (
          <div className="bg-error-500/10 border border-error-500 text-white p-4 rounded-md mb-6 flex items-start">
            <FiAlertCircle className="text-error-500 mr-2 mt-0.5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              label="Full Name"
              type="text"
              placeholder="John Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              icon={<FiUser />}
            />
          </div>
          <div>
            <Input
              label="Email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              icon={<FiMail />}
            />
          </div>
          <div>
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              icon={<FiLock />}
            />
          </div>
          <div>
            <Input
              label="Confirm Password"
              type="password"
              placeholder="••••••••"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              icon={<FiLock />}
            />
          </div>
          <div className="flex items-center mt-4">
            <input
              id="terms"
              name="terms"
              type="checkbox"
              required
              className="h-4 w-4 bg-dark-100 border-gray-700 rounded focus:ring-accent-950"
            />
            <label htmlFor="terms" className="ml-2 text-sm text-gray-300">
              I agree to the <a href="#" className="text-accent-950 hover:text-accent-600">Terms of Service</a> and <a href="#" className="text-accent-950 hover:text-accent-600">Privacy Policy</a>
            </label>
          </div>
          <div className="mt-6">
            <Button
              type="submit"
              fullWidth
              disabled={loading}
            >
              {loading ? 'Creating account...' : 'Create Account'}
            </Button>
          </div>
        </form>
        
        <div className="mt-6 text-center text-sm">
          <span className="text-gray-400">Already have an account?</span>
          <Link to="/login" className="ml-1 text-accent-950 hover:text-accent-600">
            Sign in
          </Link>
        </div>
      </div>
    </motion.div>
  )
}

export default Register