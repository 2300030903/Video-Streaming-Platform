import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useVideos } from '../contexts/VideoContext'
import VideoGrid from '../components/videos/VideoGrid'
import Loading from '../components/common/Loading'
import Button from '../components/common/Button'

const Watchlist = () => {
  const { getWatchlistVideos, loading } = useVideos()
  const [watchlistVideos, setWatchlistVideos] = useState([])
  
  useEffect(() => {
    if (!loading) {
      setWatchlistVideos(getWatchlistVideos())
    }
  }, [loading, getWatchlistVideos])
  
  if (loading) {
    return <Loading />
  }

  return (
    <motion.div
      className="container-custom py-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="heading-lg mb-8">My Watchlist</h1>
      
      {watchlistVideos.length > 0 ? (
        <VideoGrid
          videos={watchlistVideos}
          emptyMessage="Your watchlist is empty"
        />
      ) : (
        <div className="bg-dark-200 rounded-lg p-8 text-center max-w-2xl mx-auto">
          <h2 className="heading-sm mb-4">Your watchlist is empty</h2>
          <p className="text-gray-400 mb-6">
            Start adding videos to your watchlist to keep track of what you want to watch next.
          </p>
          <Button
            variant="primary"
            onClick={() => window.location.href = '/browse'}
          >
            Browse Videos
          </Button>
        </div>
      )}
    </motion.div>
  )
}

export default Watchlist