import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FiEdit2, FiSave, FiUser, FiMail } from 'react-icons/fi'
import { useAuth } from '../contexts/AuthContext'
import { useVideos } from '../contexts/VideoContext'
import Button from '../components/common/Button'
import VideoGrid from '../components/videos/VideoGrid'
import Input from '../components/common/Input'
import Loading from '../components/common/Loading'

const Profile = () => {
  const { currentUser, updateProfile } = useAuth()
  const { getContinueWatchingVideos, loading } = useVideos()
  
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [editMode, setEditMode] = useState(false)
  const [saving, setSaving] = useState(false)
  const [continueWatchingVideos, setContinueWatchingVideos] = useState([])
  
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name)
      setEmail(currentUser.email)
    }
  }, [currentUser])
  
  useEffect(() => {
    if (!loading) {
      setContinueWatchingVideos(getContinueWatchingVideos())
    }
  }, [loading, getContinueWatchingVideos])
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      setSaving(true)
      await updateProfile({ name })
      setEditMode(false)
    } catch (error) {
      console.error('Error updating profile:', error)
    } finally {
      setSaving(false)
    }
  }
  
  if (loading) {
    return <Loading />
  }

  return (
    <motion.div
      className="container-custom py-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="heading-lg mb-8">My Profile</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {/* Profile Card */}
        <div className="bg-dark-200 rounded-lg p-6 md:col-span-1">
          <div className="flex flex-col items-center mb-6">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-32 h-32 rounded-full object-cover mb-4 border-4 border-accent-950"
            />
            <h2 className="text-xl font-semibold">{currentUser.name}</h2>
            <p className="text-gray-400 text-sm">
              {currentUser.isAdmin ? 'Admin Account' : 'Standard Account'}
            </p>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <Input
                label="Name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={!editMode}
                icon={<FiUser className="text-gray-400" />}
              />
              
              <Input
                label="Email"
                type="email"
                value={email}
                disabled
                icon={<FiMail className="text-gray-400" />}
              />
              
              {editMode ? (
                <div className="flex space-x-3">
                  <Button
                    type="submit"
                    disabled={saving}
                    fullWidth
                    icon={<FiSave />}
                  >
                    {saving ? 'Saving...' : 'Save Changes'}
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      setName(currentUser.name)
                      setEditMode(false)
                    }}
                    fullWidth
                  >
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button
                  type="button"
                  onClick={() => setEditMode(true)}
                  fullWidth
                  icon={<FiEdit2 />}
                >
                  Edit Profile
                </Button>
              )}
            </div>
          </form>
        </div>
        
        {/* Watch History */}
        <div className="md:col-span-2">
          <h2 className="heading-md mb-4">Continue Watching</h2>
          
          {continueWatchingVideos.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {continueWatchingVideos.map(video => (
                <VideoGrid
                  key={video.id}
                  videos={[video]}
                  continueWatching={true}
                />
              ))}
            </div>
          ) : (
            <div className="bg-dark-200 rounded-lg p-6 text-center">
              <p className="text-gray-400">You haven't watched any videos yet.</p>
              <Button
                variant="primary"
                className="mt-4"
                onClick={() => window.location.href = '/browse'}
              >
                Browse Videos
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Subscription Info - Just for UI demonstration */}
      <div className="bg-dark-200 rounded-lg p-6 mb-12">
        <h2 className="heading-md mb-4">Subscription</h2>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-accent-950 font-semibold text-lg mb-1">Premium Plan</p>
            <p className="text-gray-400">Your next billing date is October 15, 2023</p>
          </div>
          <Button
            variant="secondary"
            className="mt-4 md:mt-0"
          >
            Manage Subscription
          </Button>
        </div>
      </div>
    </motion.div>
  )
}

export default Profile