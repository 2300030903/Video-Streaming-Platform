import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiPlay, FiPlus, FiCheck, FiClock } from 'react-icons/fi'
import { useVideos } from '../../contexts/VideoContext'

const VideoCard = ({ 
  video, 
  featured = false, 
  continueWatching = false, 
  progress = 0 
}) => {
  const [isHovered, setIsHovered] = useState(false)
  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useVideos()
  const inWatchlist = isInWatchlist(video.id)

  const toggleWatchlist = (e) => {
    e.preventDefault()
    if (inWatchlist) {
      removeFromWatchlist(video.id)
    } else {
      addToWatchlist(video.id)
    }
  }

  // Card variants based on type
  const cardStyles = featured 
    ? 'w-full h-[400px] md:h-[500px] lg:h-[600px] rounded-xl overflow-hidden' 
    : 'w-full rounded-lg overflow-hidden aspect-video'
  
  const contentStyles = featured
    ? 'absolute bottom-0 left-0 w-full p-6 md:p-8 bg-gradient-to-t from-dark-300 via-dark-300/80 to-transparent'
    : 'absolute bottom-0 left-0 w-full p-4 bg-gradient-to-t from-dark-300 via-dark-300/80 to-transparent'

  const titleStyles = featured
    ? 'text-2xl md:text-3xl lg:text-4xl font-bold mb-2'
    : 'text-lg font-semibold'

  return (
    <motion.div
      className={`relative ${cardStyles} group`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.03 }}
      transition={{ duration: 0.3 }}
    >
      <Link to={`/video/${video.id}`}>
        <div className="relative w-full h-full">
          <img 
            src={video.thumbnail} 
            alt={video.title} 
            className="w-full h-full object-cover transition-all duration-300 group-hover:brightness-75"
          />
          
          {/* Overlay on hover */}
          <div 
            className={`absolute inset-0 bg-dark-300/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity duration-300`}
          >
            <motion.div 
              className="bg-accent-950 rounded-full p-3"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <FiPlay className="text-white text-2xl" />
            </motion.div>
          </div>
          
          {/* Content info */}
          <div className={contentStyles}>
            {featured && (
              <span className="inline-block px-2 py-1 bg-accent-950 text-white text-xs rounded mb-2">Featured</span>
            )}
            <h3 className={titleStyles}>{video.title}</h3>
            {featured && (
              <p className="text-gray-300 mb-3 line-clamp-2">{video.description}</p>
            )}
            <div className="flex items-center text-sm text-gray-400 mb-2">
              <span>{video.releaseYear}</span>
              <span className="mx-1">•</span>
              <span>{video.duration}</span>
              <span className="mx-1">•</span>
              <span className="flex items-center">
                {video.rating} <span className="text-yellow-500 ml-1">★</span>
              </span>
            </div>
            
            {/* Show progress bar for continue watching */}
            {continueWatching && progress > 0 && (
              <div className="mt-2">
                <div className="w-full h-1 bg-gray-700 rounded-full">
                  <div 
                    className="h-full bg-accent-950 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <div className="flex items-center mt-1 text-xs text-gray-400">
                  <FiClock className="mr-1" />
                  <span>{Math.floor(progress)}% completed</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </Link>
      
      {/* Watchlist button */}
      <button
        onClick={toggleWatchlist}
        className="absolute top-2 right-2 z-10 bg-dark-200/70 hover:bg-dark-200 p-2 rounded-full transition-all duration-200"
        aria-label={inWatchlist ? "Remove from watchlist" : "Add to watchlist"}
      >
        {inWatchlist ? (
          <FiCheck className="text-accent-950" />
        ) : (
          <FiPlus className="text-white" />
        )}
      </button>
    </motion.div>
  )
}

export default VideoCard