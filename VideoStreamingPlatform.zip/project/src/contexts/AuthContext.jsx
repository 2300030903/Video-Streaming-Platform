import { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext()

export const useAuth = () => useContext(AuthContext)

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null)
  const [loading, setLoading] = useState(true)

  const login = (email, password) => {
    // Simulating API login
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Check mock credentials
        if (email === 'user@example.com' && password === 'password') {
          const user = {
            id: '1',
            email: 'user@example.com',
            name: 'John Doe',
            avatar: 'https://i.pravatar.cc/150?img=33',
            isAdmin: false,
          }
          localStorage.setItem('user', JSON.stringify(user))
          setCurrentUser(user)
          resolve(user)
        } else if (email === 'admin@example.com' && password === 'admin') {
          const admin = {
            id: '2',
            email: 'admin@example.com',
            name: 'Admin User',
            avatar: 'https://i.pravatar.cc/150?img=68',
            isAdmin: true,
          }
          localStorage.setItem('user', JSON.stringify(admin))
          setCurrentUser(admin)
          resolve(admin)
        } else {
          reject(new Error('Invalid credentials'))
        }
      }, 1000)
    })
  }

  const register = (name, email, password) => {
    // Simulating API registration
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = {
          id: '3',
          email,
          name,
          avatar: 'https://i.pravatar.cc/150?img=3',
          isAdmin: false,
        }
        localStorage.setItem('user', JSON.stringify(user))
        setCurrentUser(user)
        resolve(user)
      }, 1000)
    })
  }

  const logout = () => {
    localStorage.removeItem('user')
    setCurrentUser(null)
  }

  const updateProfile = (updatedData) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const updatedUser = { ...currentUser, ...updatedData }
        localStorage.setItem('user', JSON.stringify(updatedUser))
        setCurrentUser(updatedUser)
        resolve(updatedUser)
      }, 1000)
    })
  }

  useEffect(() => {
    // Check if user is logged in on app load
    const user = localStorage.getItem('user')
    if (user) {
      setCurrentUser(JSON.parse(user))
    }
    setLoading(false)
  }, [])

  const value = {
    currentUser,
    login,
    register,
    logout,
    updateProfile,
    loading
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}