import VideoCard from './VideoCard'

const VideoGrid = ({ 
  videos, 
  title = '', 
  continueWatching = false, 
  emptyMessage = 'No videos available' 
}) => {
  if (!videos || videos.length === 0) {
    return (
      <div className="mb-12">
        {title && <h2 className="heading-md mb-4">{title}</h2>}
        <div className="bg-dark-200 rounded-lg p-8 text-center">
          <p className="text-gray-400">{emptyMessage}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="mb-12">
      {title && <h2 className="heading-md mb-4">{title}</h2>}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
        {videos.map(video => (
          <VideoCard 
            key={video.id} 
            video={video} 
            continueWatching={continueWatching}
            progress={continueWatching ? video.progress : 0}
          />
        ))}
      </div>
    </div>
  )
}

export default VideoGrid