import { useState, useRef, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { FiChevronLeft, FiChevronRight, FiPlay } from 'react-icons/fi'
import Button from '../common/Button'

const VideoCarousel = ({ videos }) => {
  const [current, setCurrent] = useState(0)
  const [direction, setDirection] = useState(1) // 1 for right, -1 for left
  const timeoutRef = useRef(null)

  const totalVideos = videos.length

  const next = () => {
    setDirection(1)
    setCurrent(current === totalVideos - 1 ? 0 : current + 1)
  }

  const prev = () => {
    setDirection(-1)
    setCurrent(current === 0 ? totalVideos - 1 : current - 1)
  }

  // Auto-advance
  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    
    timeoutRef.current = setTimeout(() => {
      next()
    }, 8000)
    
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [current])

  // Variants for animations
  const slideVariants = {
    enter: (direction) => ({
      x: direction > 0 ? '100%' : '-100%',
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (direction) => ({
      x: direction < 0 ? '100%' : '-100%',
      opacity: 0
    })
  }

  return (
    <div className="relative w-full h-[50vh] md:h-[70vh] lg:h-[80vh] overflow-hidden">
      {/* Navigation Arrows */}
      <button 
        className="absolute left-4 top-1/2 transform -translate-y-1/2 z-20 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full"
        onClick={prev}
        aria-label="Previous slide"
      >
        <FiChevronLeft size={24} />
      </button>
      
      <button 
        className="absolute right-4 top-1/2 transform -translate-y-1/2 z-20 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full"
        onClick={next}
        aria-label="Next slide"
      >
        <FiChevronRight size={24} />
      </button>
      
      {/* Carousel Items */}
      <AnimatePresence initial={false} custom={direction} mode="wait">
        <motion.div
          key={current}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "tween", duration: 0.8 },
            opacity: { duration: 0.5 }
          }}
          className="absolute inset-0"
        >
          <div className="relative w-full h-full">
            {/* Background Image */}
            <div className="absolute inset-0">
              <img 
                src={videos[current].thumbnail} 
                alt={videos[current].title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark-300 via-dark-300/50 to-transparent" />
            </div>
            
            {/* Content */}
            <div className="absolute bottom-0 left-0 w-full p-8 md:p-16">
              <div className="container mx-auto">
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="max-w-2xl"
                >
                  <span className="inline-block px-2 py-1 bg-accent-950 text-white text-xs rounded mb-4">
                    Featured
                  </span>
                  <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
                    {videos[current].title}
                  </h2>
                  <p className="text-gray-200 mb-6 text-base md:text-lg line-clamp-2 md:line-clamp-3">
                    {videos[current].description}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-6">
                    <span className="text-gray-300 text-sm flex items-center">
                      {videos[current].releaseYear}
                    </span>
                    <span className="text-gray-300 mx-2">•</span>
                    <span className="text-gray-300 text-sm">
                      {videos[current].duration}
                    </span>
                    <span className="text-gray-300 mx-2">•</span>
                    <span className="text-yellow-500 text-sm flex items-center">
                      {videos[current].rating} <span className="ml-1">★</span>
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    <Link to={`/video/${videos[current].id}`}>
                      <Button 
                        variant="primary"
                        icon={<FiPlay />}
                      >
                        Play Now
                      </Button>
                    </Link>
                    <Link to={`/video/${videos[current].id}`}>
                      <Button variant="secondary">
                        More Info
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
      
      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-20 flex space-x-2">
        {videos.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setDirection(index > current ? 1 : -1)
              setCurrent(index)
            }}
            className={`h-1.5 rounded-full transition-all ${
              index === current ? 'w-8 bg-accent-950' : 'w-2 bg-gray-400/60'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

export default VideoCarousel