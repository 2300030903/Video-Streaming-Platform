import { useState, useEffect } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiSearch } from 'react-icons/fi'
import { useVideos } from '../contexts/VideoContext'
import VideoGrid from '../components/videos/VideoGrid'
import Loading from '../components/common/Loading'

const Search = () => {
  const [searchParams, setSearchParams] = useSearchParams()
  const query = searchParams.get('q') || ''
  const [searchQuery, setSearchQuery] = useState(query)
  const [results, setResults] = useState([])
  const { searchVideos, loading } = useVideos()

  useEffect(() => {
    if (!loading && query) {
      setResults(searchVideos(query))
    }
  }, [query, searchVideos, loading])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery })
    }
  }

  if (loading) {
    return <Loading />
  }

  return (
    <motion.div
      className="container-custom py-24"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h1 className="heading-lg mb-6">Search</h1>
        
        <form onSubmit={handleSubmit} className="mb-8">
          <div className="relative max-w-2xl">
            <input
              type="text"
              placeholder="Search for movies, TV shows..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-dark-100 text-white border border-gray-700 rounded-md pl-10 pr-4 py-3
                        focus:outline-none focus:ring-2 focus:ring-accent-950 focus:border-transparent"
            />
            <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <button
              type="submit"
              className="absolute right-3 top-1/2 transform -translate-y-1/2 bg-accent-950 hover:bg-accent-600 text-white px-4 py-1 rounded-md text-sm transition-colors"
            >
              Search
            </button>
          </div>
        </form>
        
        {query ? (
          <>
            <h2 className="heading-sm mb-4">
              Search results for "{query}" ({results.length})
            </h2>
            <VideoGrid
              videos={results}
              emptyMessage={`No results found for "${query}"`}
            />
          </>
        ) : (
          <div className="bg-dark-200 rounded-lg p-8 text-center max-w-2xl">
            <FiSearch className="mx-auto mb-4 text-gray-400" size={40} />
            <p className="text-gray-400 mb-2">Enter search terms to find videos</p>
            <p className="text-gray-500 text-sm">
              Try searching for titles, genres, actors, or directors
            </p>
          </div>
        )}
      </div>
    </motion.div>
  )
}

export default Search